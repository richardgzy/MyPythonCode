# Q1

name = input("Please input your name:")
print("Welcome, %s" % name)